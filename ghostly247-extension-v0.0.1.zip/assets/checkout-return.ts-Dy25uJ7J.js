(function(){if(location.pathname.startsWith("/r/success")){const s=new URLSearchParams(location.search).get("session_id")??void 0;try{chrome.runtime.sendMessage({type:"CHECKOUT_RETURN",payload:{sessionId:s}})}catch{}}
//# sourceMappingURL=checkout-return.ts-Dy25uJ7J.js.map
})()
