import './assets/index.ts-uRnuls2u.js';
